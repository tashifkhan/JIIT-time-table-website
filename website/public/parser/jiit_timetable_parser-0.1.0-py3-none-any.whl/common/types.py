# Backward compatibility shim — real implementation is in models/types.py
from models.types import ClassType, WeekDay, RawWeekDay, Subject, ClassInfo

__all__ = ["ClassType", "WeekDay", "RawWeekDay", "Subject", "ClassInfo"]
