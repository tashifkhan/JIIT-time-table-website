"""
Pydantic compatibility layer.

Pydantic is only used for development. In Pyodide (browser) it is not
available, so fallback plain-Python classes are provided instead.
"""

try:
    from pydantic import BaseModel, Field, RootModel
    PYDANTIC_AVAILABLE = True
except ImportError:
    PYDANTIC_AVAILABLE = False

    class BaseModel:
        """Fallback BaseModel when pydantic is not available."""
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)

    class RootModel:
        """Fallback RootModel when pydantic is not available."""
        def __init__(self, root=None):
            self.root = root

    def Field(*args, **kwargs):
        """Fallback Field function."""
        return kwargs.get('default', None)
