# Backward compatibility shim — real implementation is in utils/common.py
from utils.common import (
    parse_batch_numbers,
    is_elective,
    is_batch_included,
    batch_extractor,
    subject_extractor,
    location_extractor,
    subject_name_extractor,
    is_enrolled_subject,
    process_day,
    convert_time_format,
    process_timeslot,
    do_you_have_subject,
    type_extractor,
    pprint,
)

__all__ = [
    "parse_batch_numbers",
    "is_elective",
    "is_batch_included",
    "batch_extractor",
    "subject_extractor",
    "location_extractor",
    "subject_name_extractor",
    "is_enrolled_subject",
    "process_day",
    "convert_time_format",
    "process_timeslot",
    "do_you_have_subject",
    "type_extractor",
    "pprint",
]
