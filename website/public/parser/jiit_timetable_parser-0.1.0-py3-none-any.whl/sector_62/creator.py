# Backward compatibility shim — real implementation is in modules/tt_parsers/sector_62/creator.py
from modules.tt_parsers.sector_62.creator import (
    time_table_creator,
    time_table_creator_v2,
    creator,
    creator_year1,
)

__all__ = [
    "time_table_creator",
    "time_table_creator_v2",
    "creator",
    "creator_year1",
]
